import React, { useState } from 'react';
import { Form } from 'react-bootstrap';
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import "bootstrap/dist/css/bootstrap.min.css";
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import ExcelDownloadButton from './Excel';
// import { PDFDownloadLink, Document, Page, Text } from '@react-pdf/renderer';
// import { ExcelFile, ExcelSheet } from '@react-data-export';

function Home() {
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [options, setOptions] = useState([]);
  const [searchQuery, setSearchQuery] = useState(''); // State variable for search query

  const [newStudent, setNewStudent] = useState({
    name: '',
    address: '',
    city: '',
    country: '',
  });

  // Sample student data
  const sampleStudents = [
    { id: 1, name: 'Rual Octo', address: 'Deban Street', city: 'New York', country: 'USA' },
    { id: 2, name: 'Demark', address: 'City Road.13', city: 'Dubai', country: 'UAE' },
    { id: 3, name: 'Suresh', address: 'main Street', city: 'chennai', country: 'INDIA' },
    { id: 4, name: 'Vijay', address: 'sub road', city: 'kenya', country: 'EUROPE' },
    { id: 5, name: 'Lohith', address: '2nd cross', city: 'New city', country: 'MARACO' },
    { id: 6, name: 'Lokesh', address: 'City Road.16', city: 'mayanamar', country: 'BRAZIL' },
    
    // Add more sample data here
  ];
  const [sampleStudentsdata,setsampleStudentdata]=useState(sampleStudents)

// Function to handle the search input
    const handleSearch = (e) => {
        setSearchQuery(e.target.value);
      };

  // Function to open the view modal
  const handleView = (student) => {
    setSelectedOption(student);
    setShowViewModal(true);
  };

  // Function to open the edit modal
  const handleEdit = (student) => {
    setSelectedOption(student);
    setShowEditModal(true);
  };

  // Function to open the delete modal
  const handleDelete = (student) => {
    setSelectedOption(student);
    setShowDeleteModal(true);
  };

  // Function to open the create modal
  const handleCreate = () => {
    setShowCreateModal(true);
  };

  // Function to save changes when editing a student
  const handleSaveChanges = (editedStudent) => {
   // Find the index of the student with the matching ID
  const studentIndex = sampleStudentsdata.findIndex(item => item.id === editedStudent.id);

  // Create a copy of the students array
  const updatedStudents = [...sampleStudentsdata];

  // Update the student data in the copied array
  if (studentIndex !== -1) {
    updatedStudents[studentIndex] = editedStudent;
  }

  // Update the state with the modified array
  setsampleStudentdata(updatedStudents);

  // Close the edit modal
  setShowEditModal(false);
};





  // Function to delete a student
  const handleConfirmDelete = (student) => {
    // Find the index of the student to delete
    const studentIndex = sampleStudentsdata.findIndex(item => item.id === student.id);
  
    if (studentIndex !== -1) {
      // Remove the student from the array
      const updatedStudentsdata = [...sampleStudentsdata];
      updatedStudentsdata.splice(studentIndex, 1);
  
      // Update the ids to be sequential
      updatedStudentsdata.forEach((student, index) => {
        student.id = index + 1;
      });
  
      setsampleStudentdata(updatedStudentsdata);
    }
  
    setShowDeleteModal(false);
  };
  

  // Function to create a new student record
  const handleCreateRecord = () => {
    // Implement the logic to create a new student record here
    // Use the values from the 'newStudent' state to create the new record
    // For example, you can add the new student to the 'sampleStudents' array
    const newId = sampleStudents.length + 1;
    const newStudentRecord = { id: newId, ...newStudent };
    setsampleStudentdata([...sampleStudentsdata, newStudentRecord]);


    setNewStudent({
      name: '',
      address: '',
      city: '',
      country: '',
    });

    setShowCreateModal(false);
  };

  //pdf converter
  const handleDownloadPDF = () => {
    const doc = new jsPDF('p', 'pt', 'a4');
    doc.setFontSize(12);
    doc.text('Student Data', 40, 40);
  
    const headers = ['ID', 'Name', 'Address', 'City', 'Country'];
    const columnWidths = [50, 200, 200, 100, 100];
    const rowHeight = 20;
    const startY = 70;
    const tableX = 40;
  
    doc.autoTable({
      head: [headers],
      body: sampleStudentsdata.map((student) => Object.values(student)),
      startY: startY,
      theme: 'striped',
      columnStyles: {
        0: { cellWidth: 40 },
        1: { cellWidth: 100 },
        2: { cellWidth: 100 },
        3: { cellWidth: 100 },
        4: { cellWidth: 100 },
      },
      tableWidth: 'auto',
    });
  
    doc.save('student-data.pdf');
  };
  
  
  
  
  

  return (
    <div className="container">
      <div className="crud shadow-lg p-3 mb-5 mt-5 bg-body rounded">
        <div className="row">
          <div className="col-sm-3 mt-5 mb-4 text-gred">
            <div className="search">
              <Form className="form-inline">
                <input className="form-control mr-sm-2" type="search" placeholder="Search Student" aria-label="Search" value={searchQuery}
                  onChange={handleSearch} />
              </Form>
            </div>
          </div>
          <div className="col-sm-3 offset-sm-2 mt-5 mb-4 text-gred" style={{ color: 'green' }}>
            <h2><b>Student Details</b></h2>
          </div>
          <div className="col-sm-3 offset-sm-1 mt-5 mb-4 text-gred">
            <Button variant="primary" onClick={handleCreate}>
              Add New Student
            </Button>
          </div>
        </div>

        <div className="row">
          <div className="table-responsive">
            <table className="table table-striped table-hover table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Address</th>
                  <th>City</th>
                  <th>Country</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
              {sampleStudentsdata
                  .filter((student) => {
                    const searchString = searchQuery.trim();
                    if (searchString === '') {
                      return true; // Show all students when search is empty
                    }
                    return (
                      student.id.toString().toLowerCase().includes(searchString) ||
                      student.name.toLowerCase().includes(searchString) ||
                      student.address.toLowerCase().includes(searchString) ||
                      student.city.toLowerCase().includes(searchString) ||
                      student.country.toLowerCase().includes(searchString)
                    );
                  })
                  .map((student) => (
                    // Render filtered students
                  <tr key={student.id}>
                    <td>{student.id}</td>
                    <td>{student.name}</td>
                    <td>{student.address}</td>
                    <td>{student.city}</td>
                    <td>{student.country}</td>
                    <td>
                      <a href="#" onClick={() => handleView(student)} title="View" data-toggle="tooltip" style={{ color: '#10ab80' }}>
                        <i className="material-icons">&#xE417;</i>
                      </a>
                      <a href="#" onClick={() => handleEdit(student)} title="Edit" data-toggle="tooltip">
                        <i className="material-icons">&#xE254;</i>
                      </a>
                      <a href="#" onClick={() => handleDelete(student)} title="Delete" data-toggle="tooltip" style={{ color: 'red' }}>
                        <i className="material-icons">&#xE872;</i>
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <Button variant="primary" onClick={handleDownloadPDF}>
          Download PDF
        </Button>
        <ExcelDownloadButton data={sampleStudentsdata} /> {/* Add the Excel download button here */}
      </div>

      {/* View Modal */}
      <Modal show={showViewModal} onHide={() => setShowViewModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>View Student</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedOption && (
            <div>
              <p><b>Name:</b> {selectedOption.name}</p>
              <p><b>Address:</b> {selectedOption.address}</p>
              <p><b>City:</b> {selectedOption.city}</p>
              <p><b>Country:</b> {selectedOption.country}</p>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowViewModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Edit Modal */}
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Student</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedOption && (
            <form>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Name"
                  value={selectedOption.name}
                  onChange={(e) => {
                    const updatedStudent = { ...selectedOption, name: e.target.value };
                    setSelectedOption(updatedStudent);
                  }}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Address"
                  value={selectedOption.address}
                  onChange={(e) => {
                    const updatedStudent = { ...selectedOption, address: e.target.value };
                    setSelectedOption(updatedStudent);
                  }}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="City"
                  value={selectedOption.city}
                  onChange={(e) => {
                    const updatedStudent = { ...selectedOption, city: e.target.value };
                    setSelectedOption(updatedStudent);
                  }}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Country"
                  value={selectedOption.country}
                  onChange={(e) => {
                    const updatedStudent = { ...selectedOption, country: e.target.value };
                    setSelectedOption(updatedStudent);
                  }}
                />
              </div>
            </form>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEditModal(false)}>
            Close
          </Button>
          <Button variant="primary" onClick={() => handleSaveChanges(selectedOption)}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Delete Student</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedOption && (
            <div>
              <p>Are you sure you want to delete the student: {selectedOption.name}?</p>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={() => handleConfirmDelete(selectedOption)}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Create Modal */}
      <Modal show={showCreateModal} onHide={() => setShowCreateModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>Create Student</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <form>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Name"
                  value={newStudent.name}
                  onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Address"
                  value={newStudent.address}
                  onChange={(e) => setNewStudent({ ...newStudent, address: e.target.value })}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="City"
                  value={newStudent.city}
                  onChange={(e) => setNewStudent({ ...newStudent, city: e.target.value })}
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Country"
                  value={newStudent.country}
                  onChange={(e) => setNewStudent({ ...newStudent, country: e.target.value })}
                />
              </div>
            </form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowCreateModal(false)}>
              Close
            </Button>
            <Button variant="primary" onClick={() => handleCreateRecord()}>
              Create
            </Button>
          </Modal.Footer>
        </Modal>
    </div>
  );
}

export default Home;
